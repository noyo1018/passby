extern uint32_t Tmp_NVIC_ISER;

extern void Enter_PowerDown(void);

extern void Leave_PowerDown(void);

