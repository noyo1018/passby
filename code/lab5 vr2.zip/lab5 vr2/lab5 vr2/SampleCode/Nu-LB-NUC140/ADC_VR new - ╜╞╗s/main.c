//
// TMR_Capture_SR04 : usi[ng Timer Capture to read Ultrasound Ranger SR-04
//
// EVB : Nu-LB-NUC140 (need to manually switch RSTCAPSEL)
// MCU : NUC140VE3CN
// Sensor: SR-04

// SR-04 connection
// Trig connected to PB8
// Echo connected to TC2/PB2 (TC0_PB15, TC1_PE5, TC2_PB2, TC3_PB3)

#include <stdio.h>
#include "NUC100Series.h"
#include "MCU_init.h"
#include "SYS_init.h"
#include "LCD.h"
#include "stdlib.h"
char Text0[16];
char Text1[16];
char Text2[16];
volatile uint8_t u8ADF;
volatile uint16_t X, Y;
volatile uint8_t  B;

void ADC_IRQHandler(void)
{
    uint32_t u32Flag;

    // Get ADC conversion finish interrupt flag
    u32Flag = ADC_GET_INT_FLAG(ADC, ADC_ADF_INT);

    if(u32Flag & ADC_ADF_INT) {
        X = ADC_GET_CONVERSION_DATA(ADC, 0);
        Y = ADC_GET_CONVERSION_DATA(ADC, 1);
    }
    ADC_CLR_INT_FLAG(ADC, u32Flag);
}

void Init_ADC(void)
{
    ADC_Open(ADC, ADC_INPUT_MODE, ADC_OPERATION_MODE, ADC_CHANNEL_MASK );
    ADC_POWER_ON(ADC);
    ADC_EnableInt(ADC, ADC_ADF_INT);
    NVIC_EnableIRQ(ADC_IRQn);
    ADC_START_CONV(ADC);	
}

int32_t main (void)
{
		unsigned char car[32] = {0x80, 0xfc, 0xfc, 0xfc, 0xfc, 0xfc, 0xfc, 0xf8, 0x40, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x03, 0x03, 0x07, 0x0f, 0x3f, 0x7f, 0x37, 0x14, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
		unsigned char stone[32] = {0x00, 0x00, 0xc0, 0xe0, 0xf0, 0xf0, 0xf8, 0xf8, 0xf8, 0xf8, 0xf0, 0xe0, 0xc0, 0xc0, 0x00, 0x00, 
0x00, 0x0e, 0x1f, 0x1f, 0x1f, 0x1f, 0x1f, 0x1f, 0x1f, 0x1f, 0x1f, 0x1f, 0x1f, 0x1f, 0x1f, 0x1c};
   
		unsigned char people[32] = {0x00, 0x00, 0x00, 0x00, 0x00, 0xe0, 0x30, 0xf0, 0xf0, 0xbc, 0x60, 0x80, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x40, 0x66, 0x17, 0x0f, 0x07, 0x07, 0x3f, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00};
		unsigned char point[32] = {0x00, 0xf0, 0xf8, 0xfc, 0xfe, 0xfe, 0x01, 0x01, 0x79, 0x79, 0x3b, 0x12, 0x86, 0xcc, 0xf8, 0xe0, 
0x00, 0x0f, 0x1f, 0x3f, 0x7f, 0x7f, 0x40, 0x40, 0x7e, 0x7e, 0x7f, 0x7f, 0x3f, 0x1f, 0x0f, 0x03};
		unsigned char car1[32] = {0x00, 0xc0, 0xc0, 0xe0, 0xf0, 0xfc, 0xfe, 0xec, 0x28, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x3f, 0x1f, 0x02, 0x0c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
		unsigned char snake1[32] = {0x00, 0x00, 0x00, 0x7c, 0xf2, 0xfe, 0x7e, 0x7c, 0x38, 0x18, 0x1c, 0x18, 0x38, 0xf8, 0xf0, 0xe0, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x06, 0x3f, 0x3f, 0x09};
		
		uint32_t u32ADCvalue;
		int place;
		uint8_t x_p,y_p;
		uint8_t x_c1,y_c1;
		uint8_t x_c2,y_c2;
		uint8_t x_c4,y_c4;
		uint8_t x_end,y_end;
		uint8_t x_s,y_s;
		uint8_t x_s1,y_s1;
		uint8_t x_stone,y_stone;
		uint8_t x_stone1,y_stone1;
		uint8_t x_stone2,y_stone2;
		uint8_t x_stone3,y_stone3;
		uint8_t x_stone4,y_stone4;
		uint8_t x_c3,y_c3;
    SYS_Init();
    Init_ADC();
	  init_LCD();
	  clear_LCD();
	  
    u8ADF = 0;
		PD14 = 0;
    GPIO_SetMode(PB, BIT0, GPIO_MODE_INPUT); // set PC0 input for button
		//draw_Bmp16x16(55,30,FG_COLOR,BG_COLOR,car);
		//print_Line(0, "Joystick");

    while(1)
		{
			place = 3;//rand()%3+1;	/*�H���@�����d*//*first*/
		/*	if(place == 1){		
				x_p=0,y_p=30;
				x_c1=16,y_c1=0;
				x_c2=32,y_c2=47;
				x_end=112,y_end=15;
				x_s=48,y_s=47;
				x_stone=64,y_stone=12;
				x_stone2=64,y_stone2=47;
				x_stone3=95,y_stone3=32;
				x_c3=82,y_c3=0;
				draw_Bmp16x16(x_p,y_p,FG_COLOR,BG_COLOR,people);
				draw_Bmp16x16(x_s,y_s,FG_COLOR,BG_COLOR,snake1);
				draw_Bmp16x16(x_c1,y_c1,FG_COLOR,BG_COLOR,car);
				draw_Bmp16x16(x_c3,y_c3,FG_COLOR,BG_COLOR,car);
				draw_Bmp16x16(x_c2,y_c2,FG_COLOR,BG_COLOR,car1);
				draw_Bmp16x16(x_stone,y_stone,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_stone2,y_stone2,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_stone3,y_stone3,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_end,y_end,FG_COLOR,BG_COLOR,point);
			}*//*
			else if(place == 2){		//�ݭn�]�p����
				
				x_p=0,y_p=30;
				x_c1=16,y_c1=0;
				x_c2=32,y_c2=47;
				x_c4=16,y_c4=25;
				x_end=112,y_end=15;
				x_s=48,y_s=47;
				x_s=95,y_s=0;
				x_stone=64,y_stone=17;
				x_stone1=112,y_stone1=36;
				x_stone2=64,y_stone2=47;
				x_stone3=95,y_stone3=32;
				x_c3=82,y_c3=0;
				draw_Bmp16x16(x_p,y_p,FG_COLOR,BG_COLOR,people);
				draw_Bmp16x16(x_s,y_s,FG_COLOR,BG_COLOR,snake1);
				draw_Bmp16x16(x_s1,y_s1,FG_COLOR,BG_COLOR,snake1);//����
				draw_Bmp16x16(x_c1,y_c1,FG_COLOR,BG_COLOR,car);
				draw_Bmp16x16(x_c3,y_c3,FG_COLOR,BG_COLOR,car);
				draw_Bmp16x16(x_c4,y_c4,FG_COLOR,BG_COLOR,car);
				draw_Bmp16x16(x_c2,y_c2,FG_COLOR,BG_COLOR,car1);
				draw_Bmp16x16(x_stone,y_stone,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_stone1,y_stone1,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_stone2,y_stone2,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_stone3,y_stone3,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_end,y_end,FG_COLOR,BG_COLOR,point);
			
			}
			else if(place == 3){		//�ݭn�]�p����
				//0
				x_p=0,y_p=10;
				//16+				
				x_stone=16,y_stone=0;
				x_stone2=16,y_stone2=15;
				x_stone3=16,y_stone3=45;
				//32
				x_s=32,y_s=47;
				//48
				x_c1=48,y_c1=0;
				//64
				x_stone4=64,y_stone4=25;
				//80
				x_c3=80,y_c3=47;
				//96
				x_s1=96,y_s1=47;
				//112
				x_end=112,y_end=47;
				x_c2=32,y_c2=47;

				draw_Bmp16x16(x_p,y_p,FG_COLOR,BG_COLOR,people);
				draw_Bmp16x16(x_s,y_s,FG_COLOR,BG_COLOR,snake1);
				draw_Bmp16x16(x_s1,y_s1,FG_COLOR,BG_COLOR,snake1);
				draw_Bmp16x16(x_c1,y_c1,FG_COLOR,BG_COLOR,car);
				draw_Bmp16x16(x_c3,y_c3,FG_COLOR,BG_COLOR,car1);
				draw_Bmp16x16(x_stone,y_stone,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_stone2,y_stone2,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_stone3,y_stone3,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_stone4,y_stone4,FG_COLOR,BG_COLOR,stone);
				draw_Bmp16x16(x_end,y_end,FG_COLOR,BG_COLOR,point);
			
			}*/
			while(x_p<112&&x_p>128&&y_p<15&&y_p>31){	//�p�G�H���S���i�J��end���I�A�N�|���򲾰�
				
			
			}
	    /*sprintf(Text0, "%d", X);
	    sprintf(Text1, "%d", Y);
			sprintf(Text2, "%d", B);
			if(X>3500){					//�ޱ��H���������A�����J�W����while��
				x+=2;
			}
			if(X<1000){
				x-=2;
			}
			if(Y>3500){
				y++;
			}
			if(Y<1000){
				y--;
			}
			if(B==0){
				clear_LCD();
				y-=5;
				if(X>3500){
					x+=2;
				}
				if(X<1000){
					x-=2;
				}
				draw_Bmp16x16(x,y,FG_COLOR,BG_COLOR,mario);
				CLK_SysTickDelay(100000);
				clear_LCD();
				y-=5;
				if(X>3500){
					x+=4;
				}
				if(X<1000){
					x-=4;
				}
				draw_Bmp16x16(x,y,FG_COLOR,BG_COLOR,mario);
				CLK_SysTickDelay(100000);
				clear_LCD();
				y+=5;
				if(X>3500){
					x+=4;
				}
				if(X<1000){
					x-=4;
				}
					draw_Bmp16x16(x,y,FG_COLOR,BG_COLOR,mario);
					CLK_SysTickDelay(100000);
				clear_LCD();
					y+=5;
				if(X>3500){
					x+=4;
				}
				if(X<1000){
					x-=4;
				}
				draw_Bmp16x16(x,y,FG_COLOR,BG_COLOR,mario);
				CLK_SysTickDelay(100000);
			}
			clear_LCD();
			draw_Bmp16x16(x,y,FG_COLOR,BG_COLOR,mario);*/

	    /*print_Line(1, Text0);
	    print_Line(2, Text1);
			print_Line(3, Text2);*/
    }
}